package com.marc.app.ticketapp;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;

import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.util.UUID;

public class TicketCreatorActivity extends AppCompatActivity {
    ImageView imageView;
    ImageButton attachImageButton, uploadImageButton;
    EditText descEditText, locationEditText;
    UUID uuid;
    FirebaseStorage firebaseStorage;
    FirebaseDatabase firebaseDatabase;
    Uri uri;
    Boolean uriWithData = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ticket_creator);

        // Firebase
        firebaseDatabase = FirebaseDatabase.getInstance();
        firebaseStorage = FirebaseStorage.getInstance();

        // Views
        imageView = findViewById(R.id.imageView);
        attachImageButton = findViewById(R.id.attachImageButton);
        uploadImageButton = findViewById(R.id.uploadImageButton);
        descEditText = findViewById(R.id.descEditText);
        locationEditText = findViewById(R.id.locationEditText);

        // Listeners
        uploadImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (uriWithData) {
                    uuid = UUID.randomUUID();

                    final StorageReference storageReference = firebaseStorage.getReference().child("photos").child(uuid + ".jpg");

                    UploadTask uploadTask;
                    uploadTask = storageReference.putFile(uri);

                    Task<Uri> urlTask = uploadTask.continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
                        @Override
                        public Task<Uri> then(@NonNull Task<UploadTask.TaskSnapshot> task) throws Exception {
                            if (!task.isSuccessful()) {
                                throw task.getException();
                            }

                            return storageReference.getDownloadUrl();
                        }
                    }).addOnCompleteListener(new OnCompleteListener<Uri>() { // Si la foto de ha subido bien
                        @Override
                        public void onComplete(@NonNull Task<Uri> task) {
                            if (task.isSuccessful()) {
                                Uri downloadUri = task.getResult();
                                Ticket ticket = new Ticket();
                                ticket.setImageURL(downloadUri.toString());
                                ticket.setDesc(descEditText.getText().toString());
                                ticket.setLocation(locationEditText.getText().toString());
                                firebaseDatabase.getReference().child("tickets").child(uuid.toString()).setValue(ticket);
                            }
                        }
                    });
                }
            }
        });

        attachImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loadImageFromGallery();
            }
        });
    }

    public void loadImageFromGallery() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, 1);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Bitmap bitmap = null;

        if (requestCode == 1 && resultCode == RESULT_OK) {
            uri = data.getData();
            uriWithData = true;

            try {
                bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), uri);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        if (bitmap != null) {
            imageView.setImageBitmap(bitmap);
        }
    }

    // Menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_back, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.goBackMenuItem:
                Intent intent = new Intent(getApplicationContext(),MainActivity.class);
                startActivity(intent);
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
