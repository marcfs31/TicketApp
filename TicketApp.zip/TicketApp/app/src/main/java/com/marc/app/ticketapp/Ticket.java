package com.marc.app.ticketapp;

public class Ticket {
    String desc, location, imageURL;

    public Ticket() {
    }

    public Ticket(String desc, String location, String imageURL, String resolved) {
        this.desc = desc;
        this.location = location;
        this.imageURL = imageURL;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getImageURL() {
        return imageURL;
    }

    public void setImageURL(String imageURL) {
        this.imageURL = imageURL;
    }
}
