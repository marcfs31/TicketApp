package com.marc.app.ticketapp;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;

import java.io.IOException;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    RecyclerView recyclerView;
    TicketAdapter ticketAdapter;
    ArrayList<Ticket> tickets = new ArrayList<>();
    FirebaseDatabase firebaseDatabase;
    FirebaseStorage firebaseStorage;
    Bitmap bitmap;
    MediaPlayer mediaPlayer;
    final static String songURL = "https://firebasestorage.googleapis.com/v0/b/ticketapp-9055a.appspot.com/o/songs%2Fhimno.mp3?alt=media&token=fe9e4bdc-40a7-4692-9702-14c6609fa7f9";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Music
        try {
            mediaPlayer = getMediaPlayer(songURL);
            mediaPlayer.start();
            mediaPlayer.setLooping(true);
        } catch (IOException e) {
            Log.i("ERROR", "Error getting the song");
        }

        // Firebase
        firebaseDatabase = FirebaseDatabase.getInstance();
        firebaseStorage = FirebaseStorage.getInstance();

        // RecyclerView
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        ticketAdapter = new TicketAdapter();
        recyclerView.setAdapter(ticketAdapter);

        // Listener para los tickets
        firebaseDatabase.getReference().child("tickets").addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                Ticket ticket;
                ticket = dataSnapshot.getValue(Ticket.class);
                tickets.add(ticket);

                ticketAdapter.notifyDataSetChanged();
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {}

            @Override
            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {}

            @Override
            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {}

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {}
        });

    }

    public class TicketAdapter extends RecyclerView.Adapter<TicketAdapter.TicketViewHolder> {

        @NonNull
        @Override
        public TicketViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
            View itemView = getLayoutInflater().inflate(R.layout.ticket_item, viewGroup,false);
            TicketViewHolder ticketViewHolder = new TicketViewHolder(itemView);

            return ticketViewHolder;
        }

        @Override
        public void onBindViewHolder(@NonNull final TicketViewHolder ticketViewHolder, int i) {
            ticketViewHolder.desc.setText(tickets.get(i).getDesc());
            ticketViewHolder.location.setText(tickets.get(i).getLocation());
            firebaseStorage.getReferenceFromUrl(tickets.get(i).imageURL).getBytes(1024*1024).addOnSuccessListener(new OnSuccessListener<byte[]>() {
                @Override
                public void onSuccess(byte[] bytes) {
                    bitmap = BitmapFactory.decodeByteArray(bytes,0,bytes.length);
                    ticketViewHolder.image.setImageBitmap(bitmap);
                }
            });
        }

        @Override
        public int getItemCount() {
            return tickets.size();
        }

        public class TicketViewHolder extends RecyclerView.ViewHolder {
            ImageView image, imageCheck;
            TextView desc, location;
            CheckBox resolved;

            public TicketViewHolder(@NonNull View itemView) {
                super(itemView);
                image = itemView.findViewById(R.id.imageView);
                desc = itemView.findViewById(R.id.descTextView);
                location = itemView.findViewById(R.id.locationTextView);
                resolved = itemView.findViewById(R.id.checkBox);
                imageCheck = itemView.findViewById(R.id.imageCheck);
                imageCheck.animate().alpha(0);
                imageCheck.bringToFront();

                resolved.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                        if (imageCheck.getAlpha() == 0) {
                            imageCheck.animate().alpha(1);
                            imageCheck.animate().translationX(-880);

                        } else {
                            imageCheck.animate().alpha(0);
                            imageCheck.animate().translationX(880);
                        }

                    }
                });
            }
        }
    }

    /**
     * Get a Bitmap from the Firebase URL of an image
     * @param imageURL
     * @return Bitmap with the image
     */
    public Bitmap getFirebaseImage(String imageURL) {
        firebaseStorage.getReferenceFromUrl(imageURL).getBytes(1024*1024).addOnSuccessListener(new OnSuccessListener<byte[]>() {
            @Override
            public void onSuccess(byte[] bytes) {
                bitmap = BitmapFactory.decodeByteArray(bytes,0,bytes.length);
            }
        });
        return bitmap;
    }

    /**
     * Get a MediaPlayer from the Firebase URL of a song
     * @param songURL
     * @return MediaPlayer with the song
     * @throws IOException
     */
    public MediaPlayer getMediaPlayer(String songURL) throws IOException {
        mediaPlayer = new MediaPlayer();
        mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
        mediaPlayer.setDataSource(songURL);
        mediaPlayer.prepare();
        return mediaPlayer;
    }

    // Menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.pausePlayButton:
                if (!mediaPlayer.isPlaying()) {
                    mediaPlayer.start();
                    item.setIcon(R.drawable.ic_pause_black_24dp);
                } else {
                    mediaPlayer.pause();
                    item.setIcon(R.drawable.ic_play_arrow_black_24dp);
                }
                return true;
            case R.id.ticketCreatorButton:
                Intent intent = new Intent(getApplicationContext(),TicketCreatorActivity.class);
                startActivity(intent);
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
